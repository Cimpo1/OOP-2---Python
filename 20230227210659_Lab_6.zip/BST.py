# Template file for lab 6.
#
class BST(object):
    '''Class that represents a Binary Search Tree.'''
    class Node(object):
        '''A single node within a BST.'''
        def __init__(self, key, val = None):
            self.key = key
            self.val = val
            self.left = None
            self.right = None
        def __repr__(self):
            return 'Node({0}, {1})'.format(self.key, self.val)

    def __init__(self):
        '''Construct an empty binary search tree.'''
        self.root = None

    def __len__(self):
        '''Compute the size (number of key/value pairs) of the BST.'''
        return BST._size(self.root)

    def __bool__(self):
        '''Convert a BST into a Boolean value. Like most Python collections,
        the logic here is that any non-empty BST evaluates as True.'''
        return self.root != None
    
    @staticmethod
    def _size(node):
        '''Compute the size of the tree below this node.'''
        if node == None:
            return 0
        else:
            return 1 + BST._size(node.left) + BST._size(node.right)

    def put(self, key, val):
        '''Insert the key-value pair into the BST.'''
        def _put(node, key, val):
            '''Helper function for the public put() method.'''
            if node == None:
                return BST.Node(key, val)
            elif key < node.key:
                node.left = _put(node.left, key, val)
            elif key > node.key:
                node.right = _put(node.right, key, val)
            else:
                node.val = val
            return node
        self.root = _put(self.root, key, val)

    @staticmethod
    def _get(node, key):
        '''Helper function for get() and contains(). Returns the node 
        associated with the key, if present. Otherwise returns None.

        This is not local so that it can be shared between the two public
        methods. However, its name starts with an underscore to emphasize
        that is should only be used by other methods in the class.

        '''
        if node == None:
            return None
        if node.key == key:
            return node
        i = node
        while i.key != key:
            if i == None:
                return None
            elif i.key > key:
                i = i.left
            elif i.key < key:
                i = i.right   
            elif i.key == key:
                return i
            if i== None:
                return None
        return i
        

    def get(self, key):
        '''Get the value associated with the given 'key'.

        Raises KeyError() if the key is not present in the BST.
        '''
        x = BST._get(self.root, key)
        if x == None:
            raise KeyError(key)
        else:
            return x.val

    def __contains__(self, key):
        '''Implements the 'in' operator.'''
        return BST._get(self.root, key) != None

    def depth(self):
        '''Return the maximum depth of the tree.

        This is defined here as follows:
        * An empty BST has depth 0
        * Any other BST has depth of 1 + max(depth(left), depth(right))
        '''
        def _depth(node):
            '''Compute the depth of the tree below this node.'''
            if node == None:
                return 0
            else:
                return 1 + max(_depth(node.left), _depth(node.right))
        return _depth(self.root)
    def minKey(self):
        '''Return the minimum key in the BST.'''
        def _minKey(node):
            '''Helper function for the public minKey() method. HEAVAILY INSPIRED FROM ORIGINAL _get() METHOD'''
            if node == None:
                return None
            elif node.left == None:
                return node.key
            else:
                return _minKey(node.left)
        return _minKey(self.root)
    def maxKey(self):
        '''Return the maximum key in the BST.'''
        def _maxKey(node):
            '''Helper function for the public maxKey() method. HEAVAILY INSPIRED FROM ORIGINAL _get() METHOD'''
            if node == None:
                return None
            elif node.right == None:
                return node.key
            else:
                return _maxKey(node.right)
        return _maxKey(self.root)
    def traverse(self, func):
        if self == None:
            return None
        BST.traverse(self.left, func)
        func(self.key, self.val)
        BST.traverse(self.right, func)
    def __repr__(self):
        '''Return a string representation of the BST.'''
        def _repr(node):
            '''Helper function for the public __repr__() method.'''
            if node == None:
                return ''
            else:
                return _repr(node.left) + ' {}:{},'.format(node.key,node.val) + _repr(node.right)
        w = _repr(self.root)
        b = w[1:-1]
        return '{' + b + '}'# I know I did not use the traverse methode but I spent like 2 Hours and I always get this error '??? repr string error' so I gave up 
