from MaxPQ import MaxPQ
from MinPQ import MinPQ

T = "PRIO*R**I*T*Y***QUE***U*E*"

q = MaxPQ()
r = []

for i in T:
    if i == '*':
        r.append(q.delete())
    else:
        q.insert(i)
print(r) # The anwser to question 1 is: ['R', 'R', 'P', 'O', 'T', 'Y', 'I', 'I', 'U', 'Q', 'E', 'U', 'E']

q = MinPQ()
r = []

for i in T:
    if i == '*':
        r.append(q.delete())
    else:
        q.insert(i)
print(r) #The anwser to question 2 is: ['I', 'O', 'P', 'I', 'R', 'R', 'T', 'Y', 'E', 'Q', 'U', 'U', 'E']

def heapsort(data, reversed=False):
    '''
    heap sort an array using a priority queue.
    This implements an in-place, N log2 N sort.
    '''
    # create a heap from the initial array.
    n = len(data) - 1
    if reversed == False:
        h = MaxPQ()
    if reversed == True:
        h = MinPQ()
    for i in data:
        h.insert(i)
    i = h._parent(n)
    while i >= 0:
        h._lower(data, i, n + 1)
        i -= 1

    # now sort the array
        while n > 0:
            data[0],data[n] = data[n],data[0]
            n -= 1
            h._lower(data, 0, n + 1)
        return h
        

yy = [2,3,5,2,2,4,5,3,2,6,8,5,2]
t = heapsort(yy, False)
assert t == [8, 6, 5, 2, 5, 5, 4, 2, 2, 2, 3, 3, 2]
t = heapsort(yy, True)
assert t == [2, 2, 2, 2, 3, 2, 4, 5, 6, 8, 5, 5, 3]
# we make this work by using the method MaxPQ when False and Method MinPQ when True


