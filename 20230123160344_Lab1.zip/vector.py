# Implements a simple 'vector' class intended to represent a
# numeric vector, rather than a general tuple.
class vector(tuple):
    '''Numeric vector class.'''
    def __add__(self, other):
        '''Implement vector addition.

        This implementation will allow for either vector + iterable
        or vector + scalar.
        '''
        ls = []
        try:
            # if this succeeds, 'other' must be iterable.
            for x, y in zip(self, other):
                ls.append(x + y)
        except TypeError:
            # zip failed, so 'other' is probably scalar.
            for x in self:
                ls.append(x + other)
        return vector(ls)

    def magnitude(self):
        '''Compute the magnitude of a vector.'''
        r = 0
        for x in self:
            r += x * x
        return r ** 0.5
    def __mul__(self, other):
        ls = []
        if type(other) is int or type(other) is float:
            for x in self:
                ls.append(x* other)
            return vector(ls)
        raise TypeError('Please us a scalar.')

a = vector((0, 3, 4))
b = vector((6, 2, 3))
assert a + b == (6, 5, 7)
assert a + 1 == (1, 4, 5)
assert a + (3, -1, -2) == (3, 2, 2)

assert a.magnitude() == 5.0
assert b.magnitude() == 7.0

# Add tests for your multiplication method here.
h = a * 2
assert h == (0, 6, 8)

print("Tests passed")
