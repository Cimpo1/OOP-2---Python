from EdgeWeightedDigraph import *

class EdgeWeightedGraph(EdgeWeightedDigraph):
    def __init__(self, V):
        super().__init__(V)

    def addEdge(self, e):
        v = e.fromVertex()
        w = e.toVertex()
        self._adj[v].append(e)
        self._adj[w].append(e)
        self._indegree[w] += 1
        self._E += 1

    def __str__(self):
        s = str(self._V) + " vertices, " + str(self._E) + " edges"
        
    def outdegree(self, v):
        '''Number of edges from 'v'.'''
        return self._indegree[v]