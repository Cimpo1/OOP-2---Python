from EdgeWeightedGraph import *
from UF import *

x = input("File? ")
fp = open(x)
G = EdgeWeightedGraph.fromfile(fp)
V = G.V()
weight = 0
edges = []
list1 = sorted(G.edges())
uf = UF(V)
for i in list1:
    if len(edges) == (V - 1):
        break
    if not uf.connected(i._v, i._w):
        weight += i._weight
        edges.append(i)
        uf.union(i._v, i._w)
for i in edges:
    print(i)
print(weight)