'''
David Cimpoiasu , 2130140
R. Vincent , instructor
Advanced Programming , section 2
Assignment 2
'''

#This is the third part

from MinPQ import MinPQ #importing tools
from Board import Board


import functools
@functools.total_ordering
class Node(object):
    def __init__(self, bd, moves, node):
        '''Construct a new node object. A node contains four attributes:
        1. The board associated with this node (Board).
        2. The number of moves to reach this node (int).
        3. The cost or distance metric for this node (int).
        4. The previous node (Node).
        '''
        self.board = bd         # save the board
        self.moves = moves      # number of moves to reach this board.
        self.cost = bd.distance() # save the distance metric.
        self.previous = node      # save the previous node.
    def __gt__(self, other):
        '''A node is 'greater' than another if the cost plus the
        number of moves is larger. Note that this code will fail
        if 'other' is None.'''
        return (self.cost + self.moves) > (other.cost + other.moves)
    def __eq__(self, other):
        '''Two nodes are equal if the sum of the cost and moves are
        the same. The board itself is ignored.'''
        if self is other:       # comparing to itself?
            return True
        if other is None:       # comparing to None
            return False
        return (self.cost + self.moves) == (other.cost + other.moves)
    def __repr__(self): #mainly created this for testing
        return "Node({}, {}, {}, {})".format(self.board, self.moves, self.cost, self.previous)



class Solver(object):
    def __init__(self, initial):
        '''Initialize the object by finding the solution for the
        puzzle.'''
        self.__solvable = False
        self.__trace = []       # List of Board objects.
        # This is where your code to solve the puzzle will go!
        
        tree = MinPQ() #creating main tree
        tree2 = MinPQ()#create twin tree
        root = initial #root of tree
        root2 = Node(initial.board.twin(), 0, None) #root the twin board
        Stat = root.board.solved() #Status of initial board
        Stat2 = root2.board.solved()#Status of twin board
        if Stat == True:
            print('It is already solved') #check if solved already
            return
        if Stat2 == True: #check twin board
            raise ValueError('No solution possible') #raise error
            
        self.loopcount = 0 #adding variable
        
        tree.insert(root) #insert root
        tree2.insert(root2) #Insert twin to twin tree
        while Stat != True or Stat2 != True: # initiat main loop, stops at the first solve
            y = tree.delete() # gets lowest value
            x = tree2.delete() #gets twin lowest level
            #print(y.board, y.moves, y.cost, '\n') #Used for testing
            neighbour = y.board.neighbors() # gets board neighbors
            n2 = x.board.neighbors() #gets twin neighbors
            #print(neighbour, '\n') #Used for testing
            for i in neighbour: #testing each neighbor
                self.loopcount += 1 #updating variable
                #print(i.distance(), '\n') #used for testing
                if y.previous != None: #check if current board is root or not
                    if i == y.previous.board: #check if neighbor is same as previous and goes to the next one if true
                        continue
                #print('previous passed') #used for testing
                if i.solved() == True: #Check if this neigbor is solution
                    self.final = i #sets final board state
                    self.__trace.append(i) #appends the final state
                    h = y #sets h as previous
                    while h!= None: #loop for creating trace
                        self.__trace.append(h.board) #appends the trace
                        h = h.previous #gets the previous of previous
                    self.__solvable = True #sets state to solved
                    self.moves = y.moves+1 #sets the total amount of moves
                    Stat = True #internal variable to make sure the loop stops
                    return #exits loop
                #print('solved passed') #testing
                NN = Node(i, y.moves + 1, y) #creating the node with all info
                #print('in tree passed') #testing
                tree.insert(NN) #inserts in tree
                #print(tree, '\n') #testing
            for i in n2: #testing twin neighbor
                if x.previous != None:
                    if i == x.previous.board: #same as previous
                        continue
                if i.solved() == True:
                    Stat2 = True #to make sure loops end
                    raise ValueError('No solution possible') # if solved, raise error 
                NN2 = Node(i, x.moves+1, x) #creates twin node next
                tree2.insert(NN2) #insert next node
            if y.moves > 60: #used for testing mainly but make sure the program stops if loop goes to far
                exit()
                
    def solvable(self):
        '''Returns True if this puzzle can be solved.'''
        return self.__solvable;
  
    def moves(self):
        '''Returns the number of moves in the solution, or -1 if
        not solvable.'''
        return len(self.__trace) - 1 if self.__solvable else -1
  
    def solution(self):
        '''Returns a list of Board objects beginning with the initial Board
        and ending with the solved Board.'''
        return self.__trace.copy()
    def __repr__(self): #mainly created this for testing
        return "Solver({}, {}, {})".format(self.__solvable, self.moves, self.__trace)
                
                
Name = input('File name?: ') #gets file name
file = open(Name) #open file
G = [] #main list for cleaning up
for l in file: #clean up each line
    l.replace('\n',"") #clean up
    h = l.split(' ') #split line
    if len(h) == 1: #if line has one value, skip, it means its the size of board
        continue
    for i in h: #for each item in split
        if i == '': #if empty str, ignore
            continue
        if i == '\n': #if line skip, ignore
            continue
        j = int(i) #str to int
        G.append(j) #appends to finished list
B = Board(G) #transforms list in board

FF = Node(B,0, None) #creates root node
Final = Solver(FF) #solver call
print('Minimum number of moves = {}'.format(Final.moves)) # print number of moves
count = 0 #internal count for print cuz I was lazy
JJ = Final.solution() #list of solution (basically the trace)
GG = [] #create list
for i in range(len(JJ)): #inverts the solution list (.reverse() does not work, idk why)
    GG.append(JJ.pop())
    
for k in GG: #loop for the prints
    print('Move # {}'.format(count)) #prints move number with count
    count+=1
    print(k, '\n') #prints the steps
print('Loopcount:', Final.loopcount) #Prints loop count
