class queueSTACK(object):
    def __init__(self):
        self.H = []
        self.L = []
        self.size = 0
        self.pointer1 = 0
    def isEmpty(self):
        if self.size == 0:
            return True
        elif self.size != 0:
            return False
    def enqueue(self, x):
        self.H.append(x)
        self.size += 1
    def dequeue(self):
        if self.size == 0:
            raise ValueError('Queue is empty')
        self.pointer1 -= 1
        d = self.H[self.pointer1]
        self.L.append(d)
        self.size -= 1
        V = self.L.pop()
        return V