from random import randint

class rectangle(object):
    def __init__(self, upper_left_x, upper_left_y, lower_right_x, lower_right_y):
        self.UX = upper_left_x
        self.UY = upper_left_y
        self.LX = lower_right_x
        self.LY = lower_right_y
        self.STR = (str(self.UX) + ', '+ str(self.UY) + ', '+ str(self.LX) + ', '+ str(self.UY))
    def __hash__(self):
        return hash(self.STR)
    def __repr__(self):
        return self.STR
        
    def __str__(self):
        return self.STR
    def __eq__(self, other):
        return self.STR == other.STR
    
dic = {}
dic1 = {}
list1 = []
for y in range(10000):
    c = randint(0,100)
    dic[rectangle(y, y+1, y+2, y+3)] = c
    list1.append(rectangle(y, y+1, y+2, y+3).__hash__())
    dic1[rectangle(y, y+1, y+2, y+3)] = c
        
for t in dic:
    assert dic[t] == dic1[t]
    
tg = set(list1)

assert len(tg) == len(list1)
        
    
print('Passed')