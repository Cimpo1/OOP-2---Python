# Use Python's built-in secure hashing module.
import hashlib

fp = open('dictionary-yawl.txt')
words = {word.strip().lower() for word in fp}
fp.close()

# Create the "rainbow table", which is just a dictionary that maps
# the hex digest to a word.

rt = {}
for word in words:
    hash = hashlib.sha256()    # Create a new sha256() hash object.
    # string must be 'encoded' as a byte string before passing it to
    # the update() method.
    hash.update(str.encode(word))
    key = hash.hexdigest()
    assert key not in rt        # Crash if there are duplicates.
    rt[key] = word              # Add an entry to the rainbow table.

# open external file
fp = open('passwords.txt')

# TODO: Use the "rainbow table" to decrypt the passwords.
print("Decrypting 'unsalted' passwords:")
count = 0
for line in fp:
    count += 1
    if count <=10:
        print(line, 'word:', rt[line.strip()])
    


# TODO: Now decrypt the salted passwords.
# To pass the salt value from the file to the hash function, you need
# to convert the Python integer to a value with two bytes. You can do this
# by using the "to_bytes()" method of the int() type. For this example,
# x.to_bytes(2, 'little') will convert the integer x into a 2-byte,
# little-endian representation. You will need to pass this value to the
# hash function's update method after you pass the encoded string value.
# 
    if count == 10:
        print("Decrypting 'salted' passwords:")
    if count > 10:
        T = []
        R = line.split()
        T.append(R[0].strip())
        y = int(R[1].strip())
        T.append(y.to_bytes(2,'little'))
        
        rtt = {}
        for word in words:
            # string must be 'encoded' as a byte string before passing it to
            # the update() method.
            hash = hashlib.sha256()
            hash.update(str.encode(word))
            hash.update(T[1])
            key = hash.hexdigest()
            assert key not in rtt        # Crash if there are duplicates.
            rtt[key] = word              # Add an entry to the rainbow table.
        print(line, 'salted word: ', rtt[T[0]])
print(count, 'passwords.')
        
    
