from queues2 import *
from time import process_time
r = 0
while r != 'n':
    repeat = int(input('How many times to run?:'))
    start = process_time()

    x = queueSTACK()
    assert x.isEmpty() == True
    for i in range(repeat):
        x.enqueue(i)
    assert x.isEmpty() == False
    f = []
    r = []
    for l in range(repeat):
        p = x.dequeue()
        f.append(p)
        r.append((repeat-1)-l)
    assert f == r
    assert x.isEmpty() == True
    end = process_time()
    print('queues2 takes', (end-start)/repeat,'seconds to enqueue and dequeue')
    r = input('Test again with different number? y/n:')

