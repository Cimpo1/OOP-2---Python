'''
David Cimpoiasu , 2130140
R. Vincent , instructor
Advanced Programming , section 2
Assignment 1
'''
from stack import stack #importing the given stack

e = 0
while e != 'n': #repeat code
    name = input('Please enter the name of the file needed to be checked(include the .py or .txt): ')#get name
    file = open(name)#open file from name
    er = 0 #number of error
    count = 0#line pointer
    T = stack()#main stack
    for line in file:#for each line in file
        count +=1#add line pointer
        if line[0] == '#':#exclude if line is coment
            continue
        for char in line:
            if char == '#':#next line
                break
            if char == '(':#add specifque char in T with location line
                T.push([1, count])
            if char == ')':
                try:
                    a = T.pop()#tries pop
                except ValueError:
                    print('At line {}, we have an extra )'.format(count))#if not possible then there is an extra )
                    er +=1#adds error
                    continue
                if a[0] != 1:#if poped value not same as current value, mismacth
                    print('At line {}, we have mismatched )'.format(count))
                    er +=1#adds error
            if char == '[':
                T.push([2, count])#add specifque char in T with location line
            if char == ']':
                try:
                    a = T.pop()#tries pop
                except ValueError:
                    print('At line {}, we have an extra ]'.format(count))#if not possible then there is an extra ]
                    er +=1#adds error
                    continue
                if a[0] != 2:#if poped value not same as current value, mismacth
                    print('At line {}, we have mismatched ]'.format(count))
                    er +=1#adds error
            if char == '{':
                T.push([3, count])#add specifque char in T with location line
            if char == '}':
                try:
                    a = T.pop()#tries pop
                except ValueError:
                    print('At line {}, we have an extra wigly line'.format(count))#if not possible then there is an extra }
                    er +=1#adds error
                    continue
                if a[0] != 3:#if poped value not same as current value, mismacth
                    print('At line {}, we have mismatched wigly line'.format(count))
                    er +=1#adds error
    if not T.isEmpty():#if not empty, remaining open bracket missing closing bracket
        for k in T:#shows all remaining open bracket with location of open bracket
            print('At line {}, we have a missing braket'.format(k[1]))
            er +=1#adds error
    if er == 0:    
        print('All tests have passed')#if no error, tests have passed
    if er != 0:
        print('There is {} error/s'.format(er))#prints total error if there are
    e = input('Would you like to check another file? y/n:')#repeat