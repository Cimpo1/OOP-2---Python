# Starting point for Lab 9.
#
from datasets import *
from classifier import normalize_dataset
from k_means import *
import matplotlib.pyplot as plt


# Read and cluster the three datasets. All three chosen datasets
# are known to have three classes.
#

n = int(input('How many times run K_means?: '))

datasets = {
    'iris': read_iris_dataset(),
    'seeds': read_seeds_dataset(),
    'wine': read_wine_dataset()
}

N_CLASSES = 3

for name, dset in datasets.items():
    dset = normalize_dataset(dset)
    list1 = []
    list2 = []
    for i in range(n):
        iter, dis, cls = k_means(dset, N_CLASSES)
        list1.append([iter, dis, cls])
        list2.append(dis)
    MIN = min(list2)
    Index = list2.index(MIN)
    iter = list1[Index][0]
    dis = list1[Index][1]
    cls = list1[Index][2]
    p = purity(dset, cls, N_CLASSES)
    print(f'{name}: iterations {iter:d}, dissimilarity {dis:.2f}, purity {p:.2f}')

# 1. The lower the dissimilarity does not mean that the purity will increase in fact in decreases for my runs
# 2. Using the dissimilarity will not really help you in finding the k because as the k grows towards the number of
# entries given, the dissimilarity will tend to approach 0
io = input('Do you want to run the graph? y/n: ')
if io == 'y':
    dset = normalize_dataset(read_wine_dataset())
    x1 = []
    x2 = []
    y1 = []
    y2 = []
    NN = int(input('How big of a k do you want?: '))
    for i in range(NN):
        k = i+1
        iter, dis, cls = k_means(dset, k)
        p = purity(dset, cls, k)
        x1.append(k)
        x2.append(k)
        y1.append(dis)
        y2.append(p*100)
    plt.plot(x1, y1, label = "Dissimilarity")
    plt.plot(x2, y2, label = "Purity")
    plt.xlabel('K')
    plt.ylabel('Purity(%)/Dissimilarity')
    plt.title('Graph of K based on Wine dataset')
    plt.legend()
    plt.show()