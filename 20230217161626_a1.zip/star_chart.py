'''
David Cimpoiasu , 2130140
R. Vincent , instructor
Advanced Programming , section 2
Assignment 1
'''
from math import log
# A few notes:
# - There are 4428 stars in stars.txt
# - Of these, 231 have one or more names associated with them.
# - Only 11 stars have two names
# - Two names are repeated, Boo_Kappa and Boo_Zeta, so there
#   are only 229 uniquely named stars.

# This constant sets the size of the map in pixels. You may change this
# if necessary to fit the map on your screen.

SIZE = 1000                     # Use this named constant!

# This constant contains a list of the files and colors to be used for
# the constellations. You do not need to change this, but may want to
# experiment with removing some items from the list during testing.

CONSTELLATION_FILES = [
    ('Cas_lines.txt', 'white'),
    ('Cyg_lines.txt', 'white'),
    ('BigDipper_lines.txt', 'white'),
    ('Bootes_lines.txt', 'white'),
    ('UrsaMinor_lines.txt', 'white'),
    ('Cepheus_lines.txt', 'white'),
    ('Draco_lines.txt', 'white'),
    ('Auriga_lines.txt', 'white'),
    ('Gemini_lines.txt', 'white')
]


def coords_to_pixel(star_x, star_y, size):
    '''Coverts the TXT file cords to PIXEL cords'''
    O = size // 2 # Finds the zero cord
    x = star_x * O + O # The fact that the TXT cords is between -1 and 1 helps us cuz we can just multiply it to half
    y = star_y * O + O # the size and it works cuz proportional and add half
    return (x, y)

def read_stars(fp):
    '''Converts the TXT file in a comprehensible data'''
    T = [] #makes a cleaned up list of the stars
    for lines in fp: #reads the file
        R = [] # creates a list of the important info of stars
        H = lines.split(maxsplit = 5) #splits the line into each info
        R.append(H[1]) # appends the number 
        R.append(float(H[2])) # appends x coords
        R.append(float(H[3])) # appends y coords
        R.append(float(H[4])) # appends magnitude
        try: # tries to find the name
            Temp = H[5] # finds the string
            TT = Temp.split(',')#tries to split if possible, will work with one item just resulting in on name list
            R.append(TT) #appends the list of names
            T.append(R)#appends the star list into the main list
        except IndexError:
            T.append(R)#appends the star list without the name
            continue
    dic1 = {}#creates the 3 dictionary
    dic2 = {}
    dic3 = {}
    for star in T:
        dic1[star[0]] = (star[1], star[2])#appends the tuple of coords to key of star number
        dic2[star[0]] = star[3]#appends the mgnitude of star to key of star number
        if len(star) == 5: #checks if names exists
            for name in star[4]:#appends the star number to multiple key names
                dic3[name.replace('_', ' ').strip().upper()] = star[0] #cleans the key
    return dic1, dic2, dic3 #returns the dic

def plot_by_magnitude(size, coords, magnitudes):
    T = coords.keys() #gets the list of key of coord dic 
    TT = magnitudes.keys() #gets the list of key of magnitudes which is the same as the previous dic and is the number of the star
    if T != TT:
        raise ValueError('Different coords and magnitudes keys') #making sure we have the same number for each star
    for K in T:
        C = coords[K] # for each key we find its coords and magnitude
        M = magnitudes[K]
        CC = coords_to_pixel(C[0], C[1], size) # we transforme coords in pixel coords
        r = log(8-M) #find the radius of star
        x = CC[0] #finds x
        y = CC[1] #finds y
        color = '#FF0000' #color set to red cuz i like red
        draw_star(x, y, r, color) #draws the star
        
def read_constellation_lines(fp):
    dic = {} #creates the main dic of lines
    for lines in fp:
        h = lines.split(',') #splits the names and/or numbers
        if h[0].strip() not in dic: #if the key star does not exists in dic, creates empty list
            dic[h[0].strip()] = []
        dic[h[0].strip()].append(h[1].strip()) #apends the value or values to a list of a key
    return dic

def plot_constellation(coords, lines, names, color, size):
    t = lines.keys() #list of keys of lines dic
    tt = coords.keys() #list of number of stars
    ttt = names.keys() #list of names of star
    x3 = '' # this is just for my debuging and to make sure this is not the error
    y3 = ''
    x4 = ''
    y4 = ''
    for key in t:
        a = lines[key] #finds the list of names and/or numbers to proceding star
        if key in tt: #check if key is star number
            c = coords[key] #finds coords
            cc = coords_to_pixel(c[0], c[1], size)#transform coords
            x3 = cc[0]#retains coords
            y3 = cc[1]
        elif key in ttt:#check if name star
            i = names[key]#finds number
            c = coords[i]#finds coords
            cc = coords_to_pixel(c[0], c[1], size)#transforms coords
            x3 = cc[0]#retains coords
            y3 = cc[1]
        else:
            raise ValueError('Did not find coords for key: ', key)#making sure it has the coords for the key
        for u in a:#for each value in list
            if u in tt:#check if number
                c = coords[u]#find coords
                cc = coords_to_pixel(c[0], c[1], size)#transform coords
                x4 = cc[0]#retain coords
                y4 = cc[1]
            elif u in ttt:#check if name
                i = names[u]#finds star number
                c = coords[i]#finds coords
                cc = coords_to_pixel(c[0], c[1], size)#transform coords
                x4 = cc[0]#retains coords
                y4 = cc[1]
            else:
                raise ValueError('Did not find coords for value: ', u)#make sure it has coords for value
            draw_line(x3, y3, x4, y4, color)#draws the line(In the For loop)

# ^^^^ADD YOUR CODE ABOVE THIS LINE^^^^
# DO NOT CHANGE ANYTHING BELOW THIS LINE!

def draw_line(x0, y0, x1, y1, color):
    '''Draw a line connecting two points, given integer coordinates for the
    start position (x0, y0) and end position (x1, y1). The color is a string, 
    either a color name (e.g. 'red') or an RGB value '#RRGGBB'.'''
    canvas.create_line(x0, y0, x1, y1, width=1, fill=color)

def draw_star(x, y, radius, color):
    '''Draw a star as a filled circle with a given center (in pixel
    coordinates), radius (in pixels), and color (as above).'''
    if radius < 1:
        canvas.create_oval(x - 1, y - 1, x + 1, y + 1, fill=color, width=1)
    else:
        canvas.create_oval(x - radius,
                           y - radius,
                           x + radius,
                           y + radius,fill=color, width=0)

# BASIC TKINTER INITIALIZATION

import tkinter as tk
wnd = tk.Tk()
canvas = tk.Canvas(wnd, width=SIZE, height=SIZE, background='black')
canvas.pack()
wnd.title('Star chart')

# THE MAIN PROGRAM IS HERE (DO NOT CHANGE THIS)!

fp = open('stars.txt')
coords, magnitudes, names = read_stars(fp)
assert len(coords) == len(magnitudes)
print("Read", len(coords), "star coordinates and magnitudes")
print("Read", len(names), "unique star names referring to ", len(set(names.values())), "distinct stars")
fp.close()
plot_by_magnitude(SIZE, coords, magnitudes)
for fname, color in CONSTELLATION_FILES:
    fp = open(fname)
    lines = read_constellation_lines(fp)
    fp.close()
    plot_constellation(coords, lines, names, color, SIZE)

# DO NOT DELETE THIS LINE!
wnd.mainloop()
