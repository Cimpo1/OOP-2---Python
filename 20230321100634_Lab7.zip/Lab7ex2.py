from graph import digraph
from bfs import *


Name = input('File name?: ') #gets file name
file = open(Name) #open file

page = int(file.readline())
pagecount = 0
listend = []
graph = digraph(page)
Degree = []
inde = []
for i in range(page):
    inde.append([i])
for line in file:
    g = line.split()
    if g[0] == '0':
            listend.append(pagecount)
            pagecount += 1
            continue
    else:
        Degree.append([int(g[0]),pagecount])
    for n in g[1:]:
        if n == '0':
            listend.append(pagecount)
            continue
        u = int(n)
        inde[u-1].append(1)
        graph.addEdge(pagecount, u-1)
    pagecount += 1


Dist, Edge = bfs(graph, 0)
if -1 in Dist:
    print('N')
else:
    print('Y')

Le = []
for i in listend:
    Path = pathTo(Edge, 0, i)
    try:
        Le.append(len(Path))
    except:
        continue
Min = min(Le)
print(Min)

li = []
for i in Degree:
    li.append(i[0])
o = max(li)
p = li.index(o)
print(Degree[p][1]+1, Degree[p][0])
y = []
for i in inde:
    h = len(i)
    y.append(h)
yy = max(y)
j = y.index(yy)
k = inde[j][0]
print(k+1, yy-1)
print(max(Le))