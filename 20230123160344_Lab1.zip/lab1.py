def n_digits(x):
    if x < 10:
        return 1
    else:
        return 1 + n_digits(x/10)
    
def subsets(ls):
    x = len(ls)
    for ii in range(x-1):
        xi = 0
        hi = ii
        ji = ii+1
        while ii < x:
            ii += 1
            print(ls[xi : ii])
            if hi >= 1:
                hi += 2
                if ji<x:
                    print(ls[xi:hi:ji])
            xi +=1
            
subsets([2,3,4])

def flatten(ls):
    if ls == []:
        return []
    a = ls[0]
    b = ls[1:]
    if type(a) is not int:
        return flatten(a) + flatten(b)
    return [a] + flatten(b)
    
x = flatten([[3,43,3],3,3,4,[33,3],5,6])
