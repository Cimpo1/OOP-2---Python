from graph import digraph
from bfs import *


Name = input('File name?: ') #gets file name
file = open(Name) #open file

page = int(file.readline())
pagecount = 0
listend = []
graph = digraph(page)
for line in file:
    g = line.split()
    if g[0] == '0':
            listend.append(pagecount)
            pagecount += 1
            continue
    for n in g[1:]:
        if n == '0':
            listend.append(pagecount)
            continue
        u = int(n)
        graph.addEdge(pagecount, u-1)
    pagecount += 1


Dist, Edge = bfs(graph, 0)
if -1 in Dist:
    print('N')
else:
    print('Y')

Le = []
tt = 0
for i in listend:
    tt +=1
    Path = pathTo(Edge, 0, i)
    try:
        Le.append(len(Path))
    except:
        continue
Min = min(Le)
print(Min)
    