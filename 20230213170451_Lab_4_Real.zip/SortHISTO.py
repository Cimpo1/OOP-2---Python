from statistics import median
from time import process_time

start = process_time()
histogram = [0]*(100+1)
x = open('data.txt')
data = []
for line in x:
    data.append(int(line))
x.close()
for value in data:
    histogram[value] += 1

count = 0
F = []
for i in histogram:
    if i == 0:
        F.append(0)
    for ii in range(i):
        F.append(count)
    count += 1
d = len(F)
if d%2 != 0:
    op = F[(d//2)]
else:
    y = d//2
    t = y+1
    op = ((F[y]+F[t])/2)
end = process_time()
print('My median is', op)
print('This takes', (end-start),'seconds')


start = process_time()
du = median(F)
end = process_time()
print("Python's median is", du )
print('This takes', (end-start),'seconds')

#Python's median is faster because it has been optimize more then mine
    
