'''
David Cimpoiasu , 2130140
R. Vincent , instructor
Advanced Programming , section 2
Assignment 3
'''

# import some necessary parts of the machine learning tools.
from classifier import *
from random import shuffle          # for random sub-sampling
from extra_trees import extra_trees # one possible suggestion!
from knnclassifier import knnclassifier
from bagging import *
import matplotlib.pyplot as plt

fp = open('spambase.data')
dataset = []
for line in fp:
    fields = line.split(',')
    data = [float(x) for x in fields[:-1]]
    label = int(fields[-1])
    dataset.append(data_item(label, data))
fp.close()

n_items = len(dataset)
n_features = len(dataset[0].data)
n_spam = sum(v.label for v in dataset)
print(f"Read {n_items} items.")
print(f"Spam {n_spam/n_items:.2%}")
print(f"{n_features} features per item.")

# The data is unfortunately organized with all of the "spam" first, followed
# by the "good" messages. To run cross-validation properly, these records
# must be "shuffled" so that each train and test set contains a similar
# number of spam and good messages.

shuffle(dataset)

# ADD YOUR CODE HERE...

#dataset = dataset[:1000] #testing purposes
dataset = normalize_dataset(dataset) #normalize for KNN

x1 = [] # for graph
x2 = []
x3 = []
x4 = []
y1 = []
y2 = []
y3 = []
y4 = []


for i in range(1, 14, 2): #for varying values of k or M
    n_folds = 4 #number of folds
    n_features = len(dataset[0].data)
    test_size = round(len(dataset) / n_folds)
    index = 0
    n_correct = 0           # count correct predictions.
    n_tested = 0
    
    TP = 0 # recorded values
    FP = 0
    TN = 0
    FN = 0
    
    for fold in range(n_folds):
        train_data = dataset[:index] + dataset[index + test_size:] #select training data
        test_data = dataset[index:index + test_size] #select test data
        p = knnclassifier(K=i) #replace with whatever classifier wanted
        p.train(train_data) #train classifier
        print('Training passed') # confirmation
        for item in test_data: #test
                if p.predict(item.data) == item.label: 
                    if p.predict(item.data) == False: 
                        TN += 1 #Record True negative
                    else:
                        TP += 1 #record true positive
                    n_correct += 1
                else:
                    if p.predict(item.data) == False:
                        FN += 1 #record false negative
                    else:
                        FP += 1 #record false positive
                n_tested += 1
        index += test_size
        print(n_tested) #print results
        print(n_correct)
        print(TN,TP,FN,FP)
    
    
    TPR = TP/(TP+FN) #calculate matrix based on number of folds
    print(f"TPR: {TPR:.2%}")
    x1.append(TPR*100) #append to graph variable (x and y reversed by accident)
    y1.append(i)
    TNR = TN/(TN+FP)
    print(f"TNR: {TNR:.2%}")
    x2.append(TNR*100)
    y2.append(i)
    FPR = 1- TNR
    print(f"FPR: {FPR:.2%}")
    x3.append(FPR*100)
    y3.append(i)
    FNR = 1- TPR
    print(f"FNR: {FNR:.2%}")
    x4.append(FNR*100)
    y4.append(i)
    
plt.plot(y1, x1, label = 'TPR') #create graph
plt.plot(y2, x2, label = 'TNR')
plt.plot(y3, x3, label = 'FPR')
plt.plot(y4, x4, label = 'FNR')

plt.xlabel('k number')
plt.ylabel('Percentage %')
plt.legend()
plt.title('KNNclassifier with variable k and database SPAM') #change title based on classifier
plt.show()


